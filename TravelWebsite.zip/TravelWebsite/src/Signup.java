
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Signup {

	public static void main(String[] args) throws Exception {
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\anshulta\\Downloads\\June\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://jt-dev.azurewebsites.net/#/SignUp");
		String title = driver.getTitle();
		System.out.println(title);
		
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
			
		
		driver.findElement(By.id("name")).sendKeys("Anshul");;
		driver.findElement(By.id("orgName")).sendKeys("Anshul");
		driver.findElement(By.id("singUpEmail")).sendKeys("glenmax12@gmail.com");
		
		WebElement checkbox = driver.findElement(By.xpath("//span[@class ='black-color ng-binding']"));
		checkbox.click();
		
		driver.findElement(By.xpath("//button[@type ='submit']")).click();
		
		Thread.sleep(5000);
		
		String text = driver.findElement(By.xpath("//div[@class='alert alert-danger alert-custom']/span")).getText();
		System.out.println(text);
	}

}
